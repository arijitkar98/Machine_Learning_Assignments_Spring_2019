README for Part 1 of the Assignment:

(1) The code for part 1 of the assignment is present in ass2_1.py
(2) The files containing the training and testing data are train_1.csv and test_1.csv
(3) The program can be run using the command --> python3 ass2_1.py
(4) On running the program, the code first loads the training data and trains a decision tree (My Model) with Gini Index measure. It
	prints the input dataset and then prints the tree in the required.
(5) It prints the Gini Index value at the root node level.
(6) It then prints the test dataset and tests the decision tree on this dataset printing the predicted label and true label for each
	data sample.
(7) It then prints the testing accuracy.
(8) It repeats the process for Information Gain on My Model.
(9) It repeats the above steps by training a decision tree classifier with scikit-learn and prints the accuracies.
