README:

(1) First run "python3 pre_process.py" to get the training and testing data from the input data.
(2) For part 1 run "python3 part1.py"
(3) For part 2 run "python3 part2.py"
